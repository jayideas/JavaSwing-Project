package UI;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import GetConnection.GetCon;
import Home.Home;

public class Login  extends JFrame {
public Login() {
	
	JLabel  jLabel,jLabel2;
	JTextField field, field2;
	JButton  button, button2;
	  
	
	jLabel=new JLabel("username");
	jLabel2 =new JLabel("password");
	field =new JTextField(20);
	field2=new  JTextField(20);
	button=new JButton("submit");
	button.addActionListener(new ActionListener() {
		
		@Override
		public void actionPerformed(ActionEvent e) {
	
			try {
				
				
	ResultSet  resultSet=GetCon.getConnection().prepareStatement("select * from info").executeQuery();
	resultSet.next();
	String  u=resultSet.getString(1);
	String  p=resultSet.getString(2);
	if(field.getText().equals(u)&& field2.getText().equals(p)) {
		
		System.out.println("login.......");
		
		new Home();
	}
	else {
		System.out.println("invalid username & password");
		
		
		
	}

			}

			  

			catch (Exception e1) {
				// TODO Auto-generated catch block
				
				e1.printStackTrace();
			}
			
			
			
		}
	});
	button2=new  JButton("reset");
	setLayout(new FlowLayout());
	
	setVisible(true);
add(jLabel);
add(field);
add(jLabel2);
add(field2);
add(button);
add(button2);

setSize(400,400);

	
	
	
	
}
public static void main(String[] args) {
	new Login();
	
}
}
