package update;


import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import GetConnection.GetCon;
import Show.Show;

public class UpdateStaff extends JFrame {

public UpdateStaff() {

JLabel  jLabel,jLabel2,jLabel3;
JTextField field,field2;
JButton button,button2;
setLayout(new FlowLayout());

jLabel =new JLabel("Update Staff Member Name");
jLabel2 =new JLabel("Where Staff Member Id");
field =new JTextField(15);
field2 =new JTextField(15);
button=new JButton("Update");
button2=new JButton("Show");

add(jLabel);
add(field);
add(jLabel2);
add(field2);
add(button);

button2.addActionListener(new ActionListener() {
	
	@Override
	public void actionPerformed(ActionEvent e) {

		new Show();
		
		
	}
});
button.addActionListener(new  ActionListener() {
	
	@Override
	public void actionPerformed(ActionEvent e) {
		 try {
			PreparedStatement preparedStatement = GetCon.getConnection().prepareStatement("update info set name=? where id=?");
			
			preparedStatement.setString(1,field.getText());
			preparedStatement.setString(2,field2.getText());
			preparedStatement.executeUpdate();
			System.out.println("Updated");
			
			
			
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	
	
	}
});





setSize(400,400);
setVisible(true);




}
public static void main(String[] args) {
	new UpdateStaff();
}	
	
}

