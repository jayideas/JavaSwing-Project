package OPeration;

public interface Operations {
void insertdata();
void updatdata();
void deletedata();
void showdata();
}
