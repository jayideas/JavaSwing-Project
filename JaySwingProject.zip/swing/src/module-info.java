/**
 * 
 */
/**
 * 
 */
module swing {
	requires java.sql;
	requires java.desktop;
}