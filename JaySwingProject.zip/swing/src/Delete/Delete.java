package Delete;




import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import GetConnection.GetCon;
import Show.Show;

public class Delete extends JFrame {

public Delete() {

JLabel  jLabel,jLabel2,jLabel3;
JTextField field,field2;
JButton button,button2;
setLayout(new FlowLayout());

jLabel =new JLabel("Enter Employee Name For Deletion");

field =new JTextField(15);

button=new JButton("Delete");
add(jLabel);
add(field);
button2=new JButton("show");


button2.addActionListener(new ActionListener() {
	
	@Override
	public void actionPerformed(ActionEvent e) {

		new Show();
		
		
	}
});

add(button);

button.addActionListener(new  ActionListener() {
	
	@Override
	public void actionPerformed(ActionEvent e) {
		 try {
			PreparedStatement preparedStatement = GetCon.getConnection().prepareStatement("delete from info where name=?");
			
			preparedStatement.setString(1,field.getText());
			
			preparedStatement.executeUpdate();
			System.out.println("Deleted");
			
			
			
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	
	
	}
});





setSize(400,400);
setVisible(true);




}
public static void main(String[] args) {
	new Delete();
}	
	
}

