package Show;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;

import GetConnection.GetCon;

public class Show extends JFrame {

    public Show() {
        // Setup layout and components
        setLayout(new FlowLayout());

        JLabel jLabel = new JLabel("Employee Data:");
        JTextArea textArea = new JTextArea(20, 20);  // Create a large text area to show data
       
        JButton button = new JButton("Show Employee Data");

        // Add components to frame
        add(jLabel);
   
        add(button);

        // Button action listener to fetch data and display it
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                  
                  
                    PreparedStatement preparedStatement = GetCon.getConnection().prepareStatement("SELECT * FROM info");
                    ResultSet resultSet = preparedStatement.executeQuery();

                    // Clear the text area before showing new data
                    textArea.setText("");

         
                    while (resultSet.next()) {
                        // Assuming 'name' is in column 1 and 'id' is in column 2 (update with actual column names)
                        String name = resultSet.getString("name");  // Column 1: 'name'
                        String id = resultSet.getString("id");  // Column 2: 'id'
                        
                        // Append the employee data to the text area
                        textArea.append("ID: " + id + ", Name: " + name + "\n");
                    }

                    System.out.println("Data shown successfully!");

                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });

        // Frame settings
        setSize(500, 400);  // Set a larger size for the frame
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void main(String[] args) {
        new Show();
    }
}
