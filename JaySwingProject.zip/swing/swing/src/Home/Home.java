package Home;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.*;

import Delete.Delete;
import GetConnection.GetCon;
import Insert.Insert;
import Show.Show;
import UI.POJO;
import update.Update;

public class Home extends JFrame {
    JMenuBar bar;
    JMenu jMenu, jMenu2, jMenu3;
    JMenuItem item, item2, item3, item4, item5, item6;

    public Home() {
    	setLayout(new FlowLayout());
        // Create the menu bar
        bar = new JMenuBar();

        // Create menus
        jMenu = new JMenu("Employee");
        jMenu2 = new JMenu("Manager");
        jMenu3 = new JMenu("Staff");

        // Create menu items
        item = new JMenuItem("Insert");
        item2 = new JMenuItem("Update");
        item3 = new JMenuItem("Delete");
        item4 = new JMenuItem("Show");
        item5 = new JMenuItem("Insert");
        item6 = new JMenuItem("Insert");

        jMenu.add(item);
        jMenu.add(item2);
        jMenu.add(item3);
        jMenu.add(item4);
        
        jMenu2.add(item5);
        jMenu3.add(item6);
        bar.add(jMenu);
        bar.add(jMenu2);
        bar.add(jMenu3);
        add(bar);
        
        
        item4.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
		
			new Show();
			
			}
		});
        item3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
		     new Delete();		
			}
		});
        item2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
		
				new Update();
				
				
			}
		});
        item.addActionListener(new ActionListener() {
			POJO Home=new POJO();
			@Override
			public void actionPerformed(ActionEvent e) {
		
				PreparedStatement preparedStatement;
				try {
					preparedStatement = GetCon.getConnection().prepareStatement("insert into info values(?,?)");
					//preparedStatement.setString(1,Home.getName());
					//preparedStatement.setString(2,Home.getId());
					//preparedStatement.executeUpdate();
					new Insert();
					
					System.out.println("inserted bro");
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
			}
		});
        setSize(400, 400);
       
        setVisible(true);
    }

    public static void main(String[] args) {
        new Home();
    }
}
